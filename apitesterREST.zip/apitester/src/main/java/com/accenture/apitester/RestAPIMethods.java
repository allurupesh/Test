package com.accenture.apitester;



import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.hasSize;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.map.MultiValueMap;
import org.eclipse.jetty.io.EndPoint;
import org.json.JSONObject;
import org.openqa.selenium.WebElement;


import com.accenture.apitester.ExcelReader;
import com.accenture.apitester.RequestData;

import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;


import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;





public class RestAPIMethods {
	private static RestAPIMethods restAPIMethods = new RestAPIMethods();

	public static RestAPIMethods getInstance() {
		return restAPIMethods;
	}
	public void Send_RestAPI() throws Exception
	{


		List<RequestData> requestDataList = ExcelReader.read();
		Map<String, String> headersMap = new HashMap<String, String>();
		MultiValueMap map = new MultiValueMap();
		headersMap.put("Authorization", "Bearer eyJhbGciOiJSUzUxMiIsImtpZCI6Im9hdXRoMiIsIng1dCI6IkllMDNMX004ZVdkZEVTMTYzc0t3ZnhFWXg3TSJ9.eyJzdWIiOiJzZ29wYTUwNiIsIkFsdEN1c3RJRCI6InNnb3BhNTA2IiwidG9rZW5fdHlwZSI6Ik9JREMtQXNzb2NpYXRlIiwiWC1EZXZpY2UtSUQiOiJHVUVTVDM2MCIsImF6cCI6IkFnZW50RGVza3RvcCIsImV4cCI6MTUzMTg2NDc0Mywic2NvcGUiOlsib3BlbmlkIiwiZW1haWwiLCJwcm9maWxlIiwiUkVBRF9DT05TVU1FUlMiLCJXUklURV9DT05TVU1FUlMiLCJSRUFEX1NUQVlTIiwiV1JJVEVfU1RBWVMiLCJXUklURV9UUklQUyIsIlJFQURfVFJJUFMiLCJSRUFEX0xPQ0FUSU9OUyJdLCJjbGllbnRfaWQiOiJBZ2VudERlc2t0b3AiLCJBY2Nlc3NHcmFudElEIjoiTzlwck5uRHZ6UW43VEU5YlRpRGkxV3ROdEJWQklHTk8iLCJpc3MiOiJhcGkubWFycmlvdHQuY29tIiwiYXVkIjoid3d3LnJpdHpjYXJsdG9uLmNvbSIsImp0aSI6IkZMd2Q5d2pBcWlQeWRCYnhTVEJ1Wnl0VXIifQ.kSW8MdpuF3PjPrBIHCCzh94w9N57_eKH-1Kt_orniqL_omRrELv_4xI4z-fcP0Cn3CUQkXXshIS35hpEoFpzWY1f3kNith1DcxDZL_RRLl2NrZxOekVE87NeAmdFFO7NpMlzxwS4Id-l3UIHcYSDXGmnRoefBRJ4y59h0fNfGJy2cXHdm-MsA588aj2fkX45nUlNUUSItUsfetxJUhWCBxWfgXpC6nWWjKZJjk_H4enb3YGTz51abSwW8tLT2dvNQsoi6I8_jFOggeOgQSYIr55eXjzCkOGdG-tAWN7NqK6wTqUJRD83ZPDLaVPxxsyOOJX_1j814GzhiJpvKC2qxQ");
	//	headersMap.put("Authorization", "Basic QWdlbnREZXNrdG9wOlJNYnRYTUVUVVRXWEF5eFhQOWgzdlJlZnlxTGgxUEhHcUlaYml1VQ==");
		
	//	headersMap.put("X-Device-ID", "GUEST360");


		for(int k=1;k<requestDataList.size();k++)				
		{
			int statuscode = 0;
			RequestData r =  requestDataList.get(k);
			
			JSONObject jsonObj = null ;
			if(r.getPayload()!= "")
			{
				jsonObj = new JSONObject(r.getPayload());
				
			}
	        /*	if(json.has("sessionId"))
	        	{
	        		json.put("sessionId",sessionidvalue);
	        	System.out.println(json.get("sessionId").toString());

	        	}*/
			String mainstr = r.getHeaders();
			String[] substr = mainstr.split(";");	
			 for(int i = 0;i<substr.length;i++)
			 {
				 System.out.println("Print : "+substr[i].toString());
				 String[] subsubstring = substr[i].split("=");
				 headersMap.put(subsubstring[0], subsubstring[1]);
				 
			 }
			 
			System.out.println("------------------------------------");
			try {
				Response response = null;
				if(r.getMethod().equals("GET")) {
					RequestSpecification req = given().config(RestAssuredConfig.config().sslConfig(io.restassured.config.SSLConfig.sslConfig().allowAllHostnames().relaxedHTTPSValidation()))
							//.contentType(ContentType.JSON)
							//.queryParam("startDate", "2016-05-28")
							 //  .contentType("application/json")
							.accept(ContentType.JSON)
							.headers(headersMap)
							.header("Authorization",Constants.SESSION_ID)
						//	.header("Authorization",  "Basic QWdlbnREZXNrdG9wOlJNYnRYTUVUVVRXWEF5eFhQOWgzdlJlZnlxTGgxUEhHcUlaYml1VQ==")
							//.body(r.getPayload());
							//   .body(jsonObj.toString());
					//.enableLoggingOfRequestAndResponseIfValidationFails()
					.log().all() ;
					System.out.println(req.toString());
					response = req.get(r.getUrl());
				

					System.out.println(response.asString());
					System.out.println(response.getStatusCode());
				}

				else
				{

					if(r.getMethod().equals("POST")) {
						RequestSpecification req = 	given().config(RestAssuredConfig.config().sslConfig(io.restassured.config.SSLConfig.sslConfig().allowAllHostnames().relaxedHTTPSValidation()))
								//.contentType(ContentType.JSON)
								//   .contentType("application/json")
								.accept(ContentType.JSON)
								//.queryParam("startDate", "2016-05-28")
								.urlEncodingEnabled(false)
								.header("Authorization",Constants.SESSION_ID)
								//.header("Authorization",  "Basic QWdlbnREZXNrdG9wOlJNYnRYTUVUVVRXWEF5eFhQOWgzdlJlZnlxTGgxUEhHcUlaYml1VQ==")
								//.body(r.getPayload());
								   .body(jsonObj.toString())
						.log().all() ;
						response = req.post(r.getUrl());
						
					}
				}
				
				System.out.println(response.asString());
				System.out.println(response.getStatusCode());
				r.setStatuscode(String.valueOf(response.getStatusCode()));
				r.setStatusline(response.getStatusLine());
				r.setResponsebody(response.getBody().asString());

				System.out.println(response.getBody().asString());
				System.out.println(response.getStatusCode());
				System.out.println(response.getStatusLine());
				requestDataList.set(k, r);
				if(statuscode==200)
				{
					HtmlReportHelper.getHtmlReporter().Insert_TC_Step(r.getUrl(), r.getPayload(), "Status Code:"+ statuscode, "Pass",
							null);
				}
				else
				{
					HtmlReportHelper.getHtmlReporter().Insert_TC_Step(r.getUrl(), r.getPayload(),"Status Code:"+ statuscode, "Fail",
							null);
				}
				statuscode= statuscode+k;

				ExcelReader.writeExcel(requestDataList);
			}catch(Exception e)
			{
				e.printStackTrace();

			}

			//  finally{

			//}


		}




	}
}
