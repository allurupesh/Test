package com.accenture.apitester;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


public class Marriott_GXPRestAPITest{
	
	

	@BeforeClass
	public void beforeClass() {
		HtmlReportHelper.getHtmlReporter();
		try {

			//launchBrowser("Chrome");
		} catch (Exception ex) {
			ex.printStackTrace();
			// log.error(ex.toString());
		}
	}
	
	@Test
	public void testPosts() {
		try {

			HtmlReportHelper.getHtmlReporter().Initiate_TC_Report("API");

			RestAPIMethods.getInstance().Send_RestAPI();
			
			

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		HtmlReportHelper.getHtmlReporter().Close_TC_Report();
		// HtmlReportHelper.getHtmlReporter().Close_Master_Report();
		// given().headers(headersMap).log().all().when().get("http://jsonplaceholder.typicode.com/posts").then().statusCode(200);
	}

	@AfterClass
	public void afterClass() {
	//	driver.quit();
		HtmlReportHelper.getHtmlReporter().Close_Master_Report();
	}

}
