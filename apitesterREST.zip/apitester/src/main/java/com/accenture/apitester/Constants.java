package com.accenture.apitester;

public class Constants {

	public static final String URL = "https://engagepropertytest.marriott.com/v1/login";
	public static final String SESSION_ID = "Bearer somevalue";
	
}